//sons do jogo
let jogada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto =  loadSound("ponto.mp3");
  jogada = loadSound ("jogada.mp3");
}
function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  tela();
  placar();
  mostraZagueiroAtacante();
  mostraZagueiroAtacanteOponente();
  movimentaJogadores1()
  movimentaJogadores2();
  mostraBolinha()
  movimentaBolinha()
  verificaColisaoCampo()
  verificaColisaoJogadores1();
  verificaColisaoJogadores2();
  pontos();
}