//variáveis da bolinha
let posicaoBolinha = [300, 200];
let diametro = 20;
let raio = diametro/2;

//velocidade da bolinha
let velocidadeBolinha = [3,3];

function mostraBolinha (){
  fill(155);
  circle(posicaoBolinha[0], posicaoBolinha[1], diametro);
}
function movimentaBolinha(){
  for (let i=0; i<posicaoBolinha.length; i++)
    posicaoBolinha[i] += velocidadeBolinha[i]
}
function verificaColisaoCampo(){
  if (posicaoBolinha[0] + raio > width-20 || posicaoBolinha[0] - raio < 15 ){
    velocidadeBolinha[0] *= -1;
  }
  if (posicaoBolinha[1] + raio > height-20 ||
     posicaoBolinha[1]- raio < 15 ){   
    velocidadeBolinha[1] *= -1;
  } 
}

