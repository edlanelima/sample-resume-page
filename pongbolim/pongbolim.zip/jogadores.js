
// variáveis do zagueiro e atacante 1: x, y, comprimento e altura
let coordenadasZagueiro1 = [120, 168, 10, 60]
let jogador1;
let posicaoLimite = [88 ,278];
let coordenadasAtacante1 = [400, 168, 10, 60];

// variáveis do zagueiro e atacante 2: x, y, comprimento e altura
let coordenadasZagueiroOponente = [475, 168, 10, 60];
let coordenadasAtacanteOponente = [200, 168, 10, 60]

function mostraZagueiroAtacante (){
  fill('#fae');
  rect(coordenadasZagueiro1[0],coordenadasZagueiro1[1],coordenadasZagueiro1[2], coordenadasZagueiro1[3])
  fill('#fae');
  rect(coordenadasAtacante1[0], coordenadasAtacante1[1],coordenadasAtacante1[2], coordenadasAtacante1[3])
}
function mostraZagueiroAtacanteOponente(){
 fill('rgb(0,255,0)');   rect(coordenadasZagueiroOponente[0],coordenadasZagueiroOponente[1],coordenadasZagueiroOponente[2], coordenadasZagueiroOponente[3])
  fill('rgb(0,255,0)');
  rect(coordenadasAtacanteOponente [0], coordenadasAtacanteOponente [1], coordenadasAtacanteOponente [2], coordenadasAtacanteOponente [3])
} 
function movimentaJogadores1(){
    if (keyIsDown (UP_ARROW)){
    coordenadasZagueiro1[1] -= 10;
    coordenadasAtacante1[1]-= 10;
      if ( coordenadasZagueiro1[1] < 88){
        coordenadasZagueiro1[1] = posicaoLimite [0]
       coordenadasAtacante1[1] = posicaoLimite[0]
      }
  }
   if (keyIsDown (DOWN_ARROW)){
     coordenadasZagueiro1[1]  += 10;
     coordenadasAtacante1[1] += 10;
     
      if (coordenadasZagueiro1[1] > 278){
         coordenadasZagueiro1[1] = posicaoLimite [1]
         coordenadasAtacante1[1] = posicaoLimite[1]
}
}
}
function movimentaJogadores2() {
  if (keyCode === 87) {
  coordenadasZagueiroOponente[1] -= 10;
  coordenadasAtacanteOponente[1]-= 10;
      if (coordenadasZagueiroOponente[1] < 88){
         coordenadasZagueiroOponente[1] = posicaoLimite [0]
         coordenadasAtacanteOponente[1] = posicaoLimite[0]
  } 
  }
  if (keyCode === 83) {
   coordenadasZagueiroOponente[1] += 10;
   coordenadasAtacanteOponente[1] += 10;
      if (coordenadasZagueiroOponente[1] > 278){
         coordenadasZagueiroOponente[1] = posicaoLimite [1]
         coordenadasAtacanteOponente[1] = posicaoLimite[1]
}
}
}
function verificaColisaoJogadores1(){
  
  if (posicaoBolinha[0] - raio < coordenadasZagueiro1[0] + coordenadasZagueiro1[2] && posicaoBolinha[1] - raio <coordenadasZagueiro1[1] + coordenadasZagueiro1[3] && posicaoBolinha[1] + raio > coordenadasZagueiro1[1]){ 
    velocidadeBolinha[0] *= -1;
    jogada.play();
  } 
   if (posicaoBolinha[0] - raio < coordenadasAtacante1[0] + coordenadasAtacante1[2] && posicaoBolinha[1] - raio <coordenadasAtacante1[1] + coordenadasAtacante1[3] && posicaoBolinha[1] + raio > coordenadasAtacante1[2]){
    velocidadeBolinha[0] *= -1;
     jogada.play();
     
}
}    
function verificaColisaoJogadores2(){
  if (posicaoBolinha[0] - raio < coordenadasZagueiroOponente[0] + coordenadasZagueiroOponente[2] && posicaoBolinha[1] - raio <coordenadasZagueiroOponente[1] + coordenadasZagueiroOponente[3] && posicaoBolinha[1] + raio > coordenadasZagueiroOponente[1]){
    velocidadeBolinha[0]*= -1;
    jogada.play();
  } 
   if (posicaoBolinha[0] - raio < coordenadasAtacanteOponente[0] + coordenadasAtacanteOponente[2] && posicaoBolinha[1] - raio <coordenadasAtacanteOponente[1] + coordenadasAtacanteOponente[3] && posicaoBolinha[1] + raio > coordenadasAtacanteOponente[1]){
   velocidadeBolinha[0] *= -1;
     jogada.play();
   }
}