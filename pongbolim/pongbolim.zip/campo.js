// Design
let corPadrao = 'rgb(0,120,0)'
let meusPontos = 0;
let pontosDoOponente = 0;


function tela(){
  // Design do campo
    //Cor do campo
    background(corPadrao)
    //Delimitação da área
    fill(corPadrao)
    rect(20, 20, 560, 360);
    // Círculos, retângulos e linha
    fill(corPadrao)
    stroke(255,250,250);
    circle(300, 200, 70);
    line(300,0, 300, 600);
  
// Traves
  //Traves maiores
  
  fill(corPadrao);
  rect(20, 135, 60, 150);
  fill(corPadrao);
  rect(520, 135, 60, 150);
  
  // Traves medianas
  fill(corPadrao);
  rect(20, 165, 20, 100);
  fill(corPadrao);
  rect(560, 165, 20, 100);
  
  // Traves pequenas
  fill(corPadrao);
  rect(580, 195, 5, 25);
  fill(corPadrao);
  rect(15, 195, 5, 25);
  
  //Arcos
  arc(20, 20, 15, 20, 0, HALF_PI);
  arc(23, 376, 10, 15, -90, -100);
  arc(598,380, 50, 50, PI, PI + QUARTER_PI, OPEN);
  arc(576, 25, 10, 15, 94.9, 110.9);
  arc(80, 210, 60, 70, 300, HALF_PI, OPEN);
  arc(520, 210, 60, 70, -300, -HALF_PI, OPEN);
}
function placar(){
  textAlign (CENTER);
  textSize (25);
  fill(color(255, 190, 30));
  fill (190);
  text(meusPontos, 170 , 26);
  fill(color(255, 140, 0));
  fill (190);
  text(pontosDoOponente,470,26);
}
function pontos(){
   colidiu = 
  collideRectCircle(20, 165, 20, 100, posicaoBolinha[0], posicaoBolinha[1], raio);
  if (colidiu){
    pontosDoOponente +=1
    ponto.play();
    voltarBolinhaPosicaoInicial()

  }
    colidiu = 
  collideRectCircle(560, 165, 20, 100, posicaoBolinha[0], posicaoBolinha[1], raio);
  if (colidiu){
    meusPontos +=1
    ponto.play();
  voltarBolinhaPosicaoInicial()
   
  }
}
function voltarBolinhaPosicaoInicial(){
  posicaoBolinha[0] = 300
  posicaoBolinha[1] = 200
}